import os

def create_folders_and_files(base_dir, structure):
    for item, sub_structure in structure.items():
        current_path = os.path.join(base_dir, item)
        if isinstance(sub_structure, dict):
            # Create folder
            os.makedirs(current_path, exist_ok=True)
            # Recursively create subfolders and files
            create_folders_and_files(current_path, sub_structure)
        else:
            # Create file
            with open(current_path, 'w') as f:
                f.write(sub_structure)

# Define the folder structure
project_structure = {
    "config": {
        "__init__.py": "",
        "model_config.yaml": "",
        "prompt_templates.yaml": "",
        "logging_config.yaml": ""
    },
    "src": {
        "__init__.py": "",
        "llm": {
            "__init__.py": "",
            "base.py": "",
            "claude_client.py": "",
            "gpt_client.py": "",
            "utils.py": ""
        },
        "prompt_engineering": {
            "__init__.py": "",
            "templates.py": "",
            "few_shot.py": "",
            "chain.py": "",
            "utils": {
                "__init__.py": "",
                "rate_limiter.py": "",
                "token_counter.py": "",
                "cache.py": "",
                "logger.py": ""
            },
            "handlers": {
                "__init__.py": "",
                "error_handler.py": ""
            }
        }
    },
    "data": {
        "cache": {},
        "prompts": {},
        "outputs": {},
        "embeddings": {}
    },
    "examples": {
        "basic_completion.py": "",
        "chat_session.py": "",
        "chain_prompts.py": ""
    },
    "notebooks": {
        "prompt_testing.ipynb": "",
        "response_analysis.ipynb": "",
        "model_experimentation.ipynb": ""
    },
    "requirements.txt": "",
    "setup.py": "",
    "README.md": "",
    "Dockerfile": ""
}

def main():
    create_folders_and_files(base_dir="genai_project", structure=project_structure)
    print("Folder Structure Created! Happy coding fellas! If you like this handy tool follow me on LinkedIn @ https://www.linkedin.com/in/ashjoresume/")